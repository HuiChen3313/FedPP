pip install scipy
pip install tqdm
pip install matplotlib
pip install torch